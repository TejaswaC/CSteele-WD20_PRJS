var firstName = prompt("Enter First Name");
var lastName = prompt("ENter Last Name");
var age = prompt("Enter user's age");
console.log(firstName + " "+lastName );
console.log(age);