

var ans = prompt("Are we there yet?");


while(ans!=="yes" &&  ans!="yeah")
{


ans = prompt("Are we there yet?");


}

alert("Yes we made it");