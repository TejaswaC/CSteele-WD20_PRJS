var j = 10;

while(j<20)
{
	console.log(j);
	j++;
}


j=10;
while(j<41)
{
	if(j%2==0)
	{
		console.log(j)
	}
	j=j+2;
}

j=301;

while(j<334)
{
	if(j%2!=0)
	{
		console.log(j)
	}
	j=j+2;


}


j = 5

while(j<51)
{
if(j%5==0 && j%3==0)
{
	console.log(j)
}
j=j+1;
}