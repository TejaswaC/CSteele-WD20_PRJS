/*function printReverse(arr)
{
	for(var i=arr.length-1;i>=0;i--)
	{
		console.log(arr[i]);
	}
}








var arr =[1,2,3,4,5];

var arr =[1,2,3,4,5];


printReverse(arr);*/


/*function isUniform(arr)
{
	var b = true;
	var c = arr[0];
	arr.forEach(function(a){
if(c!==a){
b = false};
	});
return b;
}

var ar = [1,1,1,1,1,1,1,1];

console.log(isUniform(ar));

var ar2 = [1,1,1,1,1,1,1,1,2];

console.log(isUniform(ar2));

var ar3 = [2,2,2,2,2,2,2,2,2];

console.log(isUniform(ar3));*/


function sumArray(arr)
{
	var sum =0 ;
	arr.forEach(function(a){
		sum = sum + a;
	})
	console.log(sum);
}

var arr = [1,2,3,4,5,6,7,8,9,10];

sumArray(arr);


function max(ar2)
{
	var m=ar2[0];
	ar2.forEach(function(a){
		if(a>m){
			m=a;
		}
	});
	console.log(m);
}


var ar2 = [1,2,3,4,5,6,7,8,9,10,1,3,24,35,2,12,1,1,1];

max(ar2);
