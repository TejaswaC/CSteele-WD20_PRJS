/*var age = prompt("How old are you?");
var days = (age * 356) + age/4;
alert("You are " +days+ " days old.");*/

/*var age = prompt("Enter your age:");

if (age<18)
{
	alert("you cannot enter");

}

else if(age>=18 && age<23)
{
	alert("Can enter but not drink");
}
else
{
	alert("Can enter and drink!!!!");
}*/


var  num = 5;

var guess = Number(prompt("Guess the number"));
console.log(guess);
if (guess>5)
{
	alert("Too high");
}

else if(guess<5)
{
	alert("Too low");
}
else{
	alert("CORRECT!!!");
}
