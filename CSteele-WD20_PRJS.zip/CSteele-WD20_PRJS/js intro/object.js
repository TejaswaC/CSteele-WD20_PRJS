var movies = [
{
"seen":"not yet",
"name":"Khoon bhari maang",
"rating":4.2

},
{
"seen":"definitely",
"name":"Do Ajnabee",
"rating":4

},

{
"seen":"not yet",
"name":"kuch toh hai",
"rating":5

}
]


movies.forEach(function(movie){
console.log("You have " + movie.seen + " seen " + movie.name+ " and rated it:" + movie.rating)



})