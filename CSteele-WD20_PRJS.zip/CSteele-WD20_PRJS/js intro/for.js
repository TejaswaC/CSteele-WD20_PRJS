console.log("Numbe bw 10and 19");

for(var i =10;i<20;i++)
{
	console.log(i);
}


console.log("even bw 10 and 15");

for(var i =10;i<16;i=i+2)
{
	console.log(i);
}


console.log("odd 300 and 333");

for(var i =301;i<334;i=i+2)
{
	console.log(i);
}

console.log("divisible by 5 and 3 bw 5 and 50");

for(var i =5;i<51;i++)
{
	if(i%3==0 && i%5==0)
	{
	console.log(i);}
}