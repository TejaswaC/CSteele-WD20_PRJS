function isEven(n)
{
	if (n%2==0)
	{
		return true;
	}
	return false;
}

function factorial(n)
{
	var sol =1;
	for(var i =1; i<=n;i++)
	{
		sol = sol*i;
	}
	return sol;
}

function kebabToSnake(str)
{
	str = str.replace("/-/g","_");
	return str;
}


var num 