

$('ul').on("click","li",done);
$('input[type="text"]').keypress(addt);
$('ul').on("click","span",del);
$('.ab').on("click",tskPane);


function tskPane(){
	$('input').fadeToggle();
}

function done()
{
	$(this).toggleClass("done");
	/*if($(this).css("color")==="rgb(128, 128, 128)")
	{
$(this).removeClass("done");
	}
	else{
		$(this).addClass("done");
	}*/
	/*$(this).css("color","gray");
	$(this).css("text-decoration","line-through");*/
	console.log("propagay0ef");
}

function del(event)
{
	$(this).parent().fadeOut(500, function(){
		$(this).remove();
	})
	event.stopPropagation();
}

function addt(event){
	if(event.which === 13)
	{
	var tdt = ($(this).val());
	$('ul').append("<li><span><i class=\"fas fa-trash\"></i></span> " + tdt+ "</li>");
	$(this).val("");
}
}