const app = require("express")(),
      mongoose = require("mongoose"),
      bodyParser = require("body-parser");
      expressSanitizer = require("express-sanitizer");
      methodOverride = require("method-override");




const express = require("express");
app.use(methodOverride("_method"));
mongoose.connect("mongodb://localhost:27017/blog",{useNewUrlParser:true});


app.set("view engine", "ejs");

app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended: true}));
app.use(methodOverride("_method"));
app.use(expressSanitizer());
var blogSchema = new mongoose.Schema({
    title: String,
    image:String,
    body: String,
    created: {type: Date, default: Date.now}
});

var blog = mongoose.model("blog",blogSchema);

/* blog.create({
    title : "Test Blog",
    image : "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fupload.wikimedia.org%2Fwikipedia%2Fcommons%2Fthumb%2F1%2F1c%2FNazrul_Tirtha.JPG%2F1200px-Nazrul_Tirtha.JPG&f=1&nofb=1",
    body : "This is an online, self-paced bootcamp that’s a great next step after one of my Udemy courses to accelerate your web development skills and land a high-paying job as a software engineer. You’ll be paired with a personal mentor (an industry expert from companies like Google & Airbnb) who will answer your questions and review your code every week. I've been working with hiring managers to develop a cutting-edge curriculum that covers everything from Python, SQL, and Flask to the latest in JavaScript like React.js, Redux, and Node.js. The curriculum will include exclusive new videos and content that I’ve created. As part of the course, you’ll build your own production-ready web apps to showcase to employers."
});  */

//Restfu ROutes
app.get("/", (request,response) => {
    response.redirect("/blogs");
   // response.render("edit");
});

app.get("/blogs/new", blogForm);


//app.get("/blogs/:id", showBlog);


app.get("/blogs", (request,response) => {
   // response.render("index");
   blog.find({},(error,blogs) =>{
       if(error){
           console.log("Error");
       }
       else{
           response.render("index",{blogs:blogs});
       }
   })

} )


app.post("/blogs",postBlog);

app.get("/blogs/:id", showPage);

app.get("/blogs/:id/edit", editBlog);

app.put("/blogs/:id", updateBlog);

app.delete("/blogs/:id", deleteBlog);

function blogForm(request, response){
    response.render("new");
}

function postBlog(request, response){
    blog.create(request.body.blog, (error, newBlog) => {
        if(error){
                console.log(error);
        }
        else{
                console.log(newBlog.title);
                response.rdirect("/");

        }
    });
}

function showPage(request, response){
    console.log(request.params.id);
    blog.findById(request.params.id, (error, foundBlog) => {
        if(error){
            console.log(error);
        }
        else{
            console.log(foundBlog.title);
            response.render("show",{blog: foundBlog});
        }
    })
}
/*
function showBlog(request, response){
    blog.findById(request.body.id, (error, foundBlog) => {
        if(error){
            console.log(error);
        }
        else{
            response.render("show",{blog : foundBlog});
        }
    })
} */

function editBlog(request, response){
    blog.findById(request.params.id, (error, foundBlog)=>{
        if(error){
            console.log(error);
        }
        else{
            response.render("edit",{blog:foundBlog});
        }
    })
};

function updateBlog(request, response){
    request.body.blog.body = request.sanitize(request.body.blog.body);
    blog.findByIdAndUpdate(request.params.id,request.body.blog,(error,updatedBlog) =>{
        if(error){
            console.log(error);
        }
        else{
            console.log(request.body.blog.name);
            response.redirect("/blogs/"+request.params.id);
        }
    })
}


function deleteBlog(request, response){
blog.findByIdAndDelete(request.params.id,(error) =>{
    if(error){
        console.log(error);
    }
    else{
        console.log("Deleted");
        response.rdirect("/");


    }
})
}

app.listen(3000,() => {
    console.log("Blog running on 3000.");
})