var lis = document.querySelectorAll("li");

/*lis[0].addEventListener("mouseover",function(){
	lis[0].classList.add("selected");});

lis[0].addEventListener("mouseout",function(){
	lis[0].classList.remove("selected");});

lis[0].addEventListener("click",function(){
	lis[0].classList.toggle("done");});*/

lis.forEach(listProperty);



function listProperty(liste){
liste.addEventListener("mouseover",function(){
	liste.classList.add("selected");});

liste.addEventListener("mouseout",function(){
	liste.classList.remove("selected");});

liste.addEventListener("click",function(){
	liste.classList.toggle("done");});
}