
window.setTimeout(function() {

var todo = [];

var input;
while(input !== "quit")
{
 input = prompt("What would you like to do");

if (input === "list"){

	todo.forEach(function(d,num,k){
		console.log("************");
		console.log(num + ". " + d + " of " + k);
		console.log("************");

	})
	//console.log(todo);
}

else if(input == "new")
{
	todo.push(prompt("What would you like to add"));
}

else if (input == "delete"){
var index = prompt("Index of element to be deleted");
todo.splice(index,1);
}
else{
alert("invalid input");
}}
}, 1000);