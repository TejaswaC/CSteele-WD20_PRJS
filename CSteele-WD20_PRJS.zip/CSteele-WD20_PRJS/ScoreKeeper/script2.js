var s1 = document.querySelector("#s1");

var s2 = document.querySelector("#s2");

var ws = document.querySelector("#ws");

var inp = document.querySelector("#inp");

var p1 = document.querySelector("#p1");

var p2 = document.querySelector("#p2");

var rset2 = document.querySelector("#reset");

var score1 = 0;
var score2 = 0;
var winningScore = 5 ;
var gameOver = false;

p1.addEventListener("click",ap1);
p2.addEventListener("click",ap2);
rset2.addEventListener("click",rset);
inp.addEventListener("change",wschange);




function ap1()
{
	if(!gameOver){
		score1+=1;
		s1.textContent = score1;
	}

	if(score1 == winningScore){
		s1.classList.add("winner");
		gameOver = true;
	}

}

function ap2()
{
	if(!gameOver){
		score2+=1;
		s2.textContent = score2;
	}

	if(score2 == winningScore){
		s2.classList.add("winner");
		gameOver = true;
	}

}


function rset()
{
	score1 =0;
	score2 =0;
	s2.textContent = score2;
			s1.textContent = score1;
					s2.classList.remove("winner");

		s1.classList.remove("winner");
		gameOver = false;



}

function wschange(){
	winningScore = inp.value;
	console.log(winningScore);
	ws.textContent = winningScore;
	rset(); 
}