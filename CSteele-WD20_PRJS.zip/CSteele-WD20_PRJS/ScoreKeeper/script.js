var p1 = document.querySelector("#p1");

var p2 = document.querySelector("#p2");

var s1 = document.querySelector("#s1");

var s2 = document.querySelector("#s2");
var winningscore = 5;
var inp = document.querySelector("#inp");
var ws = document.querySelector("#ws");

console.log("winningscre = " + winningscore);
var score1 = 0;
var score2 = 0;
var reset = document.querySelector("#reset");

p1.addEventListener("click", addp1);


p2.addEventListener("click", addp2);


reset.addEventListener("click", rest);

ws.addEventListener("change",cws);

var gameOver = false;

function addp1(){
		if(!gameOver){

	score1 +=1;
	s1.textContent = score1;}
	if(score1==winningscore){
					s1.classList.add("winner");

		gameOver=true;
	}

}


function addp2(){
	if(!gameOver){
	score2 +=1;
		s2.textContent = score2;}
		if(score2===winningscore){
			s2.classList.add("winner");
		gameOver=true;
	}

}

if(gameOver == true){

}

function rest(){
	score1=0;score2 = 0;
			s2.textContent = score2;
		s1.textContent = score1;
			s2.classList.remove("winner");
			s1.classList.remove("winner");

	gameOver = false;
	
}


function cws(){
	//document.querySelector("#ws").innerHTML=winningscore;
		winningscore=Number(inp.value);
		ws.innerHtml = winningscore;
		rest();


}


