
var diff= 6;

var color = generateRandomColors(diff);
var squares = document.querySelectorAll(".square");
var ans = document.querySelector("#ans");
var h1 = document.querySelector("h1");
var reset = document.querySelector("#reset");
var easy = document.querySelector("#easy");
var hard = document.querySelector("#hard");

easy.addEventListener("click",setEasy);

hard.addEventListener("click",setHard);

function setHard(){
	diff =6;
	rset();
	hard.classList.add("selected");
		easy.classList.remove("selected");
		squares[3].style.display = "block";
			squares[5].style.display = "block";

			squares[4].style.display = "block";


}

function setEasy(){
	diff =3;
	rset();
		easy.classList.add("selected");
			hard.classList.remove("selected");
			squares[3].style.display = "none";
			squares[5].style.display = "none";

			squares[4].style.display = "none";




}




reset.addEventListener("click",rset);


var pickedColor = pickColor();
var colorDisplay = document.querySelector("#colorDisplay");
colorDisplay.textContent = pickedColor;
for(var i=0;i<diff;i++)
{
	squares[i].style.backgroundColor = color[i];

	squares[i].addEventListener("click",function(){
		var clickedColor = this.style.backgroundColor;
		if(clickedColor === pickedColor){
			alert("Correct");
			document.querySelector("#ans").textContent = "CORRECT";
			changeColors();
			h1.style.backgroundColor = clickedColor;
				reset.textContent ="Play Again";

		}
		else{
			alert("Wrong");
			this.style.backgroundColor = "#232323";
			document.querySelector("#ans").textContent = "Wrong Try Again";

		}
	})
}

function setColor(nc){
	for(var i=0;i<diff;i++)

{
	squares[i].style.backgroundColor = nc[i];

	}
}


function changeColors(){
for(var i=0;i<diff;i++)
{
	squares[i].style.backgroundColor = pickedColor;


}
pickedColor = pickColor();
}

function pickColor(){
	var random =Math.floor(Math.random() * color.length);
	console.log(random);
	return color[random];
 }

function rset(){
	color =  generateRandomColors(diff);
	setColor(color);
	pickedColor = pickColor();
	h1.style.backgroundColor =  "steelblue";
	colorDisplay.textContent = pickedColor;
					reset.textContent ="New Colors";
ans.textContent ="";


}

function generateRandomColors(diff){

var col =[];
var c1,c2,c3;
for (var i =0;i<diff;i++){
	c1 = Math.floor(Math.random()*256);
	c2 = Math.floor(Math.random()*256);
	c3 = Math.floor(Math.random()*256);

	col[i] = "rgb("+c1+", "+c2+", "+c3+")";
	console.log(col[i]);

}
return col;


}