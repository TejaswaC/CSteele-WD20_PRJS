var b = document.querySelector("#b");

b.addEventListener("click", changecolor);
	var body = document.querySelector("body");

bcolor = true;
function changecolor(){
	if(bcolor){

	body.style.backgroundColor  = "red";}

	else{
		body.style.backgroundColor  = "white";
	}
	bcolor=!bcolor;
}